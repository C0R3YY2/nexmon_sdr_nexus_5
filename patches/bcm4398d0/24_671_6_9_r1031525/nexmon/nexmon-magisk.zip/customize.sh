set_perm $MODPATH/system/bin/nexutil root root 755
